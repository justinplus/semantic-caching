module SemanticCache
  class Descriptor
    attr_reader :params
    attr_accessor :content, :ttl

    def initialize(params, content, ttl)
      @params, @content, @ttl = params, content, ttl
    end

    def valid?
    end

    def invalid?
      !invalid?
    end

  end
end
