module SemanticCaching
  class Flow
    class Source
      attr_accessor :succ
    end
  end
end
