module SemanticCaching
  class message
    attr_accessor :payload, :header
  end
end

